<?php

$LANGUAGES = ["Inglés","Español"];
$PROFILES = ["Si", "No"];
$TIMEZONE = ["GTM-2", "GTM-1", "GMT", "GMT+1", "GMT+2"];

$NO_ESTABLECIDO = 'No establecido';

