<?php

$hostConf = "localhost";
$dbConf = "proyecto";
$userConf = "nolin";
$passConf = "7506";
$portConf = "3307";
$dsnConf = "mysql:host={$hostConf}:{$portConf};dbname={$dbConf};charset=utf8mb4";